import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import {LoginSignup} from '../login-signup';
import {Router} from '@angular/router';
import {LoginSignupService} from '../login-signup.service';
import {ActivatedRoute,ParamMap} from '@angular/router';
@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {
  public id1;
  loginForm: FormGroup;
  submitted = false;
  logSign : LoginSignup = new LoginSignup();
  logSignNew : LoginSignup = new LoginSignup();
  constructor(private formBuilder: FormBuilder,private router: Router, private service : LoginSignupService,private route:ActivatedRoute) { }

  ngOnInit() {
    this.loginForm = this.formBuilder.group({
      email: ['',[Validators.required,Validators.email]],
      password: ['',[Validators.required]]
        });
        this.route.paramMap.subscribe((params:ParamMap)=>{
          let id2=parseInt(params.get("id"));
          this.id1=id2;
        })
  }

  get f() { return this.loginForm['controls']; }

  onSubmit(values) {
    this.submitted = true;

    // stop here if form is invalid
    if (this.loginForm.invalid) {
        return;
    }
    this.logSign.email=values.email;
    this.logSign.password=values.password;
    this.service.requestLogin(values.email).subscribe( data =>{
      this.logSignNew=data;
      if(this.logSignNew.email==values.email && this.logSignNew.password==values.password)
      {
        alert("logged in");
      }
    });   
}

signUpComp()
{
  this.router.navigate(["/signup"]);
}
}
