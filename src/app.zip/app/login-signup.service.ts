import { Injectable } from '@angular/core';
import {HttpHeaders,HttpClient} from '@angular/common/http';
import {LoginSignup} from './login-signup'

const httpOptions={
  headers:new HttpHeaders({'Content-Type':'application/json'})
}

@Injectable({
  providedIn: 'root'
})
export class LoginSignupService { 

  constructor(private http : HttpClient) { }
  private userUrl = 'http://localhost:9988';

  public requestLogin(email) {
  //  alert(this.userUrl+"/login/"+email);
    return this.http.get<LoginSignup>(this.userUrl+"/login/"+email);
  }

  public addUser(loginsignup) {
    return this.http.post<LoginSignup>(this.userUrl+"/signup", loginsignup);
  }
  
  
}
