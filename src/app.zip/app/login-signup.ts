export class LoginSignup {
    firstName:String;
    lastName:String;
    gender:String;
    country:String;
    email:String;
    password:String

}
